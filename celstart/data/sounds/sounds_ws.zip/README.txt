All sounds in this archive were found at:
http://www.wavsource.com/

Check their usage policy to see what is acceptable or not.

